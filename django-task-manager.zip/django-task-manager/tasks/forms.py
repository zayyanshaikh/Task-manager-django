from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import Task


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ["title", "description", "priority", "due_date", "is_completed"]
        widgets = {
            "due_date": forms.DateInput(attrs={"type": "date"}),
            "description": forms.Textarea(attrs={"rows": 4}),
        }


class SignUpForm(UserCreationForm):
    """Separate class so you can add fields (e.g. email) later."""
