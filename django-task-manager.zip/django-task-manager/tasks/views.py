from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.decorators.http import require_POST
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import SignUpForm, TaskForm
from .models import Task


class OwnedTaskMixin(LoginRequiredMixin):
    """Every query is scoped to the logged-in user, so users can't touch
    each other's tasks (even by guessing IDs in the URL)."""

    model = Task
    success_url = reverse_lazy("task_list")

    def get_queryset(self):
        return Task.objects.filter(user=self.request.user)


class TaskListView(OwnedTaskMixin, ListView):
    template_name = "tasks/task_list.html"
    context_object_name = "tasks"
    paginate_by = 10

    def get_queryset(self):
        qs = super().get_queryset()
        status = self.request.GET.get("status")
        q = self.request.GET.get("q", "").strip()
        if status == "pending":
            qs = qs.filter(is_completed=False)
        elif status == "done":
            qs = qs.filter(is_completed=True)
        if q:
            qs = qs.filter(Q(title__icontains=q) | Q(description__icontains=q))
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["status"] = self.request.GET.get("status", "")
        ctx["q"] = self.request.GET.get("q", "")
        return ctx


class TaskCreateView(OwnedTaskMixin, CreateView):
    form_class = TaskForm
    template_name = "tasks/task_form.html"

    def form_valid(self, form):
        form.instance.user = self.request.user  # never trust the client for ownership
        messages.success(self.request, "Task add ho gaya.")
        return super().form_valid(form)


class TaskUpdateView(OwnedTaskMixin, UpdateView):
    form_class = TaskForm
    template_name = "tasks/task_form.html"

    def form_valid(self, form):
        messages.success(self.request, "Task update ho gaya.")
        return super().form_valid(form)


class TaskDeleteView(OwnedTaskMixin, DeleteView):
    template_name = "tasks/task_confirm_delete.html"

    def form_valid(self, form):
        messages.success(self.request, "Task delete ho gaya.")
        return super().form_valid(form)


@login_required
@require_POST  # state changes must never happen on GET
def toggle_task(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    task.is_completed = not task.is_completed
    task.save(update_fields=["is_completed"])
    return redirect(request.POST.get("next") or "task_list")


class SignUpView(CreateView):
    form_class = SignUpForm
    template_name = "registration/signup.html"
    success_url = reverse_lazy("task_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)  # auto-login after signup
        return response
