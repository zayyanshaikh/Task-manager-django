from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Task

User = get_user_model()


class TaskTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user("alice", password="pass12345!")
        self.bob = User.objects.create_user("bob", password="pass12345!")
        self.task = Task.objects.create(user=self.alice, title="Alice's task")

    def test_login_required(self):
        resp = self.client.get(reverse("task_list"))
        self.assertEqual(resp.status_code, 302)
        self.assertIn("/accounts/login/", resp.url)

    def test_user_only_sees_own_tasks(self):
        self.client.login(username="bob", password="pass12345!")
        resp = self.client.get(reverse("task_list"))
        self.assertNotContains(resp, "Alice's task")

    def test_cannot_edit_other_users_task(self):
        self.client.login(username="bob", password="pass12345!")
        resp = self.client.get(reverse("task_update", args=[self.task.pk]))
        self.assertEqual(resp.status_code, 404)

    def test_create_task_sets_owner(self):
        self.client.login(username="bob", password="pass12345!")
        self.client.post(reverse("task_create"), {"title": "Bob's task", "priority": "high"})
        self.assertTrue(Task.objects.filter(user=self.bob, title="Bob's task").exists())

    def test_toggle_requires_post(self):
        self.client.login(username="alice", password="pass12345!")
        resp = self.client.get(reverse("task_toggle", args=[self.task.pk]))
        self.assertEqual(resp.status_code, 405)
        self.client.post(reverse("task_toggle", args=[self.task.pk]))
        self.task.refresh_from_db()
        self.assertTrue(self.task.is_completed)
