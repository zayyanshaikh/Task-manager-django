# Django Task Manager

A multi-user to-do app built with Django. Each user signs up, logs in, and manages only their own tasks.

## Features
- Sign up / login / logout (Django's built-in auth)
- Create, edit, delete, and toggle tasks
- Priority levels, due dates, overdue highlighting
- Search, status filter, pagination
- Per-user data isolation (covered by tests)
- Admin panel at `/admin/`

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser   # optional, for /admin/
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Run tests

```bash
python manage.py test
```

## Production notes
Set these environment variables before deploying:

| Variable | Example |
|---|---|
| `DJANGO_SECRET_KEY` | a long random string |
| `DJANGO_DEBUG` | `0` |
| `DJANGO_ALLOWED_HOSTS` | `yourdomain.com` |

Also switch SQLite to PostgreSQL and serve static files via WhiteNoise or a CDN.

## Project structure

```
config/      project settings and root URLs
tasks/       the app: models, views, forms, tests, migrations
templates/   base layout + task and auth pages
```
